import React, { useEffect, useMemo, useState } from 'react'
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, BarChart, Bar } from 'recharts'

const fmt = (n, digits=2) => Number(n ?? 0).toLocaleString('en-IN', { maximumFractionDigits: digits, minimumFractionDigits: digits })
const pct = n => `${(Number(n ?? 0) * 100).toFixed(2)}%`

export default function App() {
  const [inputs, setInputs] = useState(null)
  const [result, setResult] = useState(null)
  const [sensitivity, setSensitivity] = useState([])
  const [error, setError] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    fetch('/api/valuation/default')
      .then(r => { if (!r.ok) throw new Error('Could not load API defaults. Is the backend running?'); return r.json() })
      .then(setInputs).catch(e => setError(e.message))
  }, [])

  const updateValuation = (key, value) => setInputs(prev => ({
    ...prev, valuation: { ...prev.valuation, [key]: Number(value) }
  }))
  const updateForecast = (key, value) => setInputs(prev => ({
    ...prev, forecast: { ...prev.forecast, [key]: prev.forecast[key].map((v, i) => i === 0 ? Number(value) : v) }
  }))

  async function calculate() {
    if (!inputs) return
    setBusy(true); setError('')
    try {
      const [calcRes, sensRes] = await Promise.all([
        fetch('/api/valuation/calculate', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(inputs) }),
        fetch('/api/valuation/sensitivity', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify(inputs) })
      ])
      const calc = await calcRes.json()
      if (!calcRes.ok) throw new Error(calc.message || calc.error || 'Valuation calculation failed')
      setResult(calc)
      setSensitivity(sensRes.ok ? await sensRes.json() : [])
    } catch (e) { setError(e.message) }
    finally { setBusy(false) }
  }

  useEffect(() => { if (inputs) calculate() }, [inputs?.companyName])

  const metrics = result?.metrics || {}
  const forecast = result?.forecast || []
  const upside = metrics['Implied Upside / (Downside)'] ?? 0
  const sensitivityGrowthKeys = ['0.025','0.030','0.035','0.040','0.045','0.050']

  function downloadForecast() {
    if (!forecast.length) return
    const cols = Object.keys(forecast[0])
    const csv = [cols.join(','), ...forecast.map(row => cols.map(k => row[k]).join(','))].join('\n')
    const url = URL.createObjectURL(new Blob([csv], {type:'text/csv;charset=utf-8;'}))
    const a = document.createElement('a'); a.href = url; a.download = 'dcf_forecast.csv'; a.click(); URL.revokeObjectURL(url)
  }

  if (!inputs) return <main className="loading"><h1>DCF Valuation Studio</h1><p>{error || 'Loading model inputs…'}</p></main>

  return <main className="shell">
    <header className="topbar">
      <div><div className="eyebrow">EQUITY RESEARCH • FINANCIAL MODELING</div><h1>DCF Valuation Studio</h1><p>Discounted cash flow model & investment research dashboard</p></div>
      <div className="pill">Java Spring Boot + React</div>
    </header>

    <div className="warning"><strong>DEMO DATA:</strong> The default TCS inputs are illustrative and not verified current financial data. Replace them with sourced annual-report figures before publishing or relying on results.</div>
    {error && <div className="error">{error}</div>}

    <section className="panel input-panel">
      <div className="section-head"><div><h2>Model assumptions</h2><p>Edit key valuation assumptions and recalculate.</p></div><button onClick={calculate} disabled={busy}>{busy ? 'Calculating…' : 'Recalculate DCF'}</button></div>
      <div className="fields">
        <label>Company<input value={inputs.companyName} onChange={e=>setInputs({...inputs, companyName:e.target.value})}/></label>
        <label>Ticker<input value={inputs.ticker} onChange={e=>setInputs({...inputs, ticker:e.target.value})}/></label>
        <label>Starting revenue (₹ crore)<input type="number" value={inputs.historical.revenueCrore} onChange={e=>setInputs({...inputs,historical:{...inputs.historical,revenueCrore:Number(e.target.value)}})}/></label>
        <label>Tax rate (%)<input type="number" step="0.5" value={inputs.valuation.taxRate*100} onChange={e=>updateValuation('taxRate',Number(e.target.value)/100)}/></label>
        <label>Risk-free rate (%)<input type="number" step="0.1" value={inputs.valuation.riskFreeRate*100} onChange={e=>updateValuation('riskFreeRate',Number(e.target.value)/100)}/></label>
        <label>Equity risk premium (%)<input type="number" step="0.1" value={inputs.valuation.equityRiskPremium*100} onChange={e=>updateValuation('equityRiskPremium',Number(e.target.value)/100)}/></label>
        <label>Beta<input type="number" step="0.1" value={inputs.valuation.beta} onChange={e=>updateValuation('beta',Number(e.target.value))}/></label>
        <label>Pre-tax cost of debt (%)<input type="number" step="0.1" value={inputs.valuation.preTaxCostOfDebt*100} onChange={e=>updateValuation('preTaxCostOfDebt',Number(e.target.value)/100)}/></label>
        <label>Terminal growth (%)<input type="number" step="0.1" value={inputs.valuation.terminalGrowth*100} onChange={e=>updateValuation('terminalGrowth',Number(e.target.value)/100)}/></label>
        <label>Current share price (₹; demo)<input type="number" value={inputs.valuation.currentSharePriceInr} onChange={e=>updateValuation('currentSharePriceInr',Number(e.target.value))}/></label>
        <label>Cash (₹ crore)<input type="number" value={inputs.valuation.cashCrore} onChange={e=>updateValuation('cashCrore',Number(e.target.value))}/></label>
        <label>Debt (₹ crore)<input type="number" value={inputs.valuation.debtCrore} onChange={e=>updateValuation('debtCrore',Number(e.target.value))}/></label>
      </div>
    </section>

    {result && <>
      <section className="metric-grid">
        <Metric title="Implied value / share" value={`₹${fmt(metrics['Implied Value per Share (INR)'])}`} sub="DCF intrinsic value estimate"/>
        <Metric title="WACC" value={pct(metrics['WACC'])} sub="Weighted average cost of capital"/>
        <Metric title="Enterprise value" value={`₹${fmt(metrics['Enterprise Value (INR crore)'],0)} Cr`} sub="Operating business value"/>
        <Metric title="Implied upside / downside" value={pct(upside)} sub="Versus demo current share price" tone={upside>=0?'positive':'negative'}/>
      </section>

      <section className="chart-grid">
        <div className="panel chart-panel"><h2>Revenue forecast</h2><p>Five-year illustrative projection</p>
          <ResponsiveContainer width="100%" height={270}><LineChart data={forecast}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="year"/><YAxis tickFormatter={v=>`${Math.round(v/1000)}k`}/><Tooltip formatter={v=>`₹${fmt(v,0)} crore`}/><Line type="monotone" dataKey="revenueCrore" name="Revenue" stroke="#2563eb" strokeWidth={3}/></LineChart></ResponsiveContainer>
        </div>
        <div className="panel chart-panel"><h2>Unlevered free cash flow</h2><p>Forecast cash flow available to capital providers</p>
          <ResponsiveContainer width="100%" height={270}><BarChart data={forecast}><CartesianGrid strokeDasharray="3 3"/><XAxis dataKey="year"/><YAxis tickFormatter={v=>`${Math.round(v/1000)}k`}/><Tooltip formatter={v=>`₹${fmt(v,0)} crore`}/><Bar dataKey="ufcfCrore" name="UFCF" fill="#0f766e" radius={[5,5,0,0]}/></BarChart></ResponsiveContainer>
        </div>
      </section>

      <section className="panel"><div className="section-head"><div><h2>Five-year DCF forecast</h2><p>All currency figures in ₹ crore unless stated otherwise.</p></div><button className="secondary" onClick={downloadForecast}>Download CSV</button></div>
        <div className="table-wrap"><table><thead><tr><th>Year</th><th>Revenue</th><th>EBIT margin</th><th>EBIT</th><th>D&amp;A</th><th>CapEx</th><th>Change NWC</th><th>UFCF</th><th>PV of UFCF</th></tr></thead>
          <tbody>{forecast.map(y=><tr key={y.year}><td>{y.year}</td><td>{fmt(y.revenueCrore,0)}</td><td>{pct(y.ebitMargin)}</td><td>{fmt(y.ebitCrore,0)}</td><td>{fmt(y.daCrore,0)}</td><td>{fmt(y.capexCrore,0)}</td><td>{fmt(y.changeNwcCrore,0)}</td><td>{fmt(y.ufcfCrore,0)}</td><td>{fmt(y.pvUfcfCrore,0)}</td></tr>)}</tbody></table></div>
      </section>

      <section className="panel"><h2>Valuation bridge</h2><div className="bridge">
        {['PV of Forecast UFCF (INR crore)','PV of Terminal Value (INR crore)','Enterprise Value (INR crore)','Cash (INR crore)','Debt (INR crore)','Equity Value (INR crore)','Diluted Shares (crore)'].map(k=><div className="bridge-row" key={k}><span>{k}</span><strong>{fmt(metrics[k])}</strong></div>)}
      </div></section>

      <section className="panel"><h2>WACC / terminal-growth sensitivity</h2><p>Implied value per share (₹). Rows are WACC; columns are terminal growth. Illustrates how assumptions change valuation.</p>
        <div className="table-wrap"><table className="sensitivity"><thead><tr><th>WACC ↓ / Growth →</th>{sensitivityGrowthKeys.map(k=><th key={k}>{(Number(k)*100).toFixed(1)}%</th>)}</tr></thead>
          <tbody>{sensitivity.map(row=><tr key={row.wacc}><th>{(row.wacc*100).toFixed(1)}%</th>{sensitivityGrowthKeys.map(k=><td key={k}>{row[k]===undefined?'—':fmt(row[k])}</td>)}</tr>)}</tbody></table></div>
      </section>
      <section className="panel thesis"><h2>Investment thesis checklist</h2><ul>
        <li>Explain revenue growth drivers and competitive positioning using sourced evidence.</li>
        <li>Support margins, reinvestment, and working-capital assumptions with historical data.</li>
        <li>Justify risk-free rate, beta, equity risk premium, debt cost, and capital weights.</li>
        <li>Discuss bull / base / bear scenarios, valuation sensitivity, and key risks.</li>
        <li>State clearly that the model is an estimate, not a guaranteed price target.</li>
      </ul></section>
    </>}
    <footer>Educational project • Demo inputs only • Not investment advice</footer>
  </main>
}

function Metric({title,value,sub,tone=''}) {
  return <div className={`metric ${tone}`}><div className="metric-title">{title}</div><div className="metric-value">{value}</div><div className="metric-sub">{sub}</div></div>
}
