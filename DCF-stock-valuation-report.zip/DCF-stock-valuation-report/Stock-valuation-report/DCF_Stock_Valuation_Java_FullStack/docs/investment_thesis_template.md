# Investment Thesis — [Company Name]
**Ticker:** [Ticker] | **Valuation date:** [Date] | **Analyst:** [Name]  
**Data status:** Replace all bracketed items with source-verified data before using.

## 1. Business overview and thesis
Describe the company's business model, customer segments, geographic exposure, competitive position, and key growth drivers. Support claims with the latest annual report and investor-relations materials.

**Thesis summary:** [State the central investment view in 2–3 sentences. Do not rely solely on the DCF output.]

## 2. Financial performance and forecast
Summarize the last 3–5 years of revenue, operating profit / EBIT margin, cash conversion, capital expenditure, and working-capital trends. Explain the forecast assumptions:
- Revenue growth: [why is this reasonable?]
- EBIT margin: [historical evidence and operating drivers]
- D&A, capex, and working capital: [historical ratios and business rationale]
- Tax rate: [source and rationale]

## 3. DCF valuation
| Metric | Value | Source / assumption |
|---|---:|---|
| WACC | [x%] | [CAPM / debt cost / capital weights] |
| Terminal growth | [x%] | [long-run rationale] |
| Enterprise value | [₹ crore] | [model output] |
| Equity value | [₹ crore] | [EV less debt plus cash] |
| Implied value per share | [₹] | [equity value / diluted shares] |
| Reference market price | [₹] | [dated source] |
| Implied upside / downside | [x%] | [model output] |

Explain how much of enterprise value comes from terminal value. Include a WACC / terminal-growth sensitivity table and bull/base/bear cases.

## 4. Catalysts, risks, and conclusion
**Potential catalysts:** [e.g., stronger growth, margin expansion, new products, improved cash conversion]

**Key risks:** [competition, client concentration, regulation, currency, execution, valuation sensitivity, macro factors]

**Conclusion:** [Buy / Hold / Sell or no rating] with a balanced rationale, valuation range, and key conditions that would change the view.

## Source log
For every factual input, record: source title, URL, publication date, reporting period, page/table, and access date. Prefer official company filings and exchange disclosures. Clearly label estimates and assumptions.

**Disclaimer:** Educational analysis, not investment advice. DCF results are assumption-sensitive and do not guarantee future prices.
