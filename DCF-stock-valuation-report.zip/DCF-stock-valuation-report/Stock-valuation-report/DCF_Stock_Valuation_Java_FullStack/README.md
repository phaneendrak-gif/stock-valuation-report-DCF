# Stock Valuation Report — Java Full Stack DCF Project

A portfolio-ready starter project for a **Discounted Cash Flow (DCF) stock valuation platform** using:
- **Backend:** Java 21, Spring Boot 3, Spring Web, Bean Validation
- **Frontend:** React + Vite
- **Data:** JSON demo assumptions (easy to replace with verified data)
- **Model:** 5-year revenue / UFCF forecast, WACC, terminal value, enterprise-to-equity bridge, implied value per share, sensitivity matrix

> **Important:** Included TCS values and assumptions are illustrative demo inputs, not verified current financial data. Do not describe them as actual reported financials or use the results as investment advice. Replace them with values from company annual reports and cite sources before publishing.

## Project structure
```text
backend/       Spring Boot REST API and DCF calculation engine
frontend/      React dashboard
docs/          investment thesis template and data sourcing checklist
```

## Requirements
- Java 21+
- Maven 3.9+
- Node.js 20+ and npm

## Run the backend
Open a terminal in `backend/`:
```bash
mvn spring-boot:run
```
Backend URL: `http://localhost:8080`
API endpoints:
- `GET /api/health`
- `GET /api/valuation/default`
- `POST /api/valuation/calculate`
- `POST /api/valuation/sensitivity`

## Run the frontend
Open another terminal in `frontend/`:
```bash
npm install
npm run dev
```
Open the Vite URL shown in terminal (normally `http://localhost:5173`). Vite proxies `/api` requests to Spring Boot at port 8080.

## Model formulas
- `UFCF = EBIT × (1 − tax rate) + D&A − CapEx − change in NWC`
- `Cost of Equity = Risk-free Rate + Beta × Equity Risk Premium`
- `WACC = Equity Weight × Cost of Equity + Debt Weight × After-tax Cost of Debt`
- `Terminal Value = Final Forecast UFCF × (1 + terminal growth) / (WACC − terminal growth)`
- `Enterprise Value = PV(forecast UFCF) + PV(terminal value)`
- `Equity Value = Enterprise Value − Debt + Cash`
- `Implied Value per Share = Equity Value / Diluted Shares`

## Before publishing on GitHub
1. Replace demo inputs with verified company data from official annual reports / investor relations.
2. Add a source note for every input: URL, report title, page number, period, access date.
3. Add a valuation date and a dated share price source.
4. Document bull/base/bear scenarios and limitations.
5. Add screenshots of the running dashboard to your repository.
6. Never represent demo inputs as real company data.

## Educational disclaimer
This is an educational modeling project, not investment advice. DCF estimates are sensitive to assumptions and are not guaranteed future prices.
