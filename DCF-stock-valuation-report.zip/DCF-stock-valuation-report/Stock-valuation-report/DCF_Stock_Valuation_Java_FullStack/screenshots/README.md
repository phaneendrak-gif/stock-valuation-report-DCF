# Screenshots
Run the backend and frontend, capture the dashboard in your browser, and add genuine screenshots here before publishing the repository.
