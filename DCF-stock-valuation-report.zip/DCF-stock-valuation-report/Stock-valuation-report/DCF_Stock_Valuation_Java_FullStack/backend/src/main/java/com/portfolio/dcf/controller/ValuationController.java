package com.portfolio.dcf.controller;

import com.portfolio.dcf.model.ValuationRequest;
import com.portfolio.dcf.model.ValuationResponse;
import com.portfolio.dcf.service.DcfValuationService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173")
public class ValuationController {
    private final DcfValuationService service;
    public ValuationController(DcfValuationService service) { this.service = service; }

    @GetMapping("/health")
    public Map<String, String> health() { return Map.of("status", "UP", "application", "DCF Valuation API"); }

    @GetMapping("/valuation/default")
    public ValuationRequest defaultInputs() { return DemoData.request(); }

    @PostMapping("/valuation/calculate")
    public ValuationResponse calculate(@Valid @RequestBody ValuationRequest request) {
        try { return service.calculate(request, null, null); }
        catch (IllegalArgumentException e) { throw new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage()); }
    }

    @PostMapping("/valuation/sensitivity")
    public List<Map<String, Object>> sensitivity(@Valid @RequestBody ValuationRequest request) {
        var base = request.valuation();
        List<Double> waccs = List.of(0.075, 0.08, 0.085, 0.09, 0.095, 0.10, 0.105);
        List<Double> growths = List.of(0.025, 0.03, 0.035, 0.04, 0.045, 0.05);
        List<Map<String, Object>> result = new ArrayList<>();
        for (double wacc : waccs) {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("wacc", wacc);
            for (double growth : growths) {
                if (wacc <= growth) continue;
                var valuation = service.calculate(request, wacc, growth);
                row.put(String.format(Locale.US, "%.3f", growth),
                    valuation.metrics().get("Implied Value per Share (INR)"));
            }
            result.add(row);
        }
        return result;
    }
}
