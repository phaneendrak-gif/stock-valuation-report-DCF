package com.portfolio.dcf.service;

import com.portfolio.dcf.model.ValuationRequest;
import com.portfolio.dcf.model.ValuationResponse;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class DcfValuationService {

    public ValuationResponse calculate(ValuationRequest request, Double waccOverride, Double growthOverride) {
        var h = request.historical();
        var f = request.forecast();
        var v = request.valuation();

        if (f.revenueGrowth().size() != f.ebitMargins().size()) {
            throw new IllegalArgumentException("Revenue growth and EBIT margin arrays must have the same length.");
        }
        if (f.revenueGrowth().isEmpty()) throw new IllegalArgumentException("At least one forecast year is required.");
        if (v.equityWeight() + v.debtWeight() <= 0) throw new IllegalArgumentException("Capital weights must sum to a positive value.");

        double costOfEquity = v.riskFreeRate() + v.beta() * v.equityRiskPremium();
        double weightSum = v.equityWeight() + v.debtWeight();
        double equityWeight = v.equityWeight() / weightSum;
        double debtWeight = v.debtWeight() / weightSum;
        double afterTaxCostOfDebt = v.preTaxCostOfDebt() * (1.0 - v.taxRate());
        double wacc = waccOverride != null ? waccOverride
                : equityWeight * costOfEquity + debtWeight * afterTaxCostOfDebt;
        double terminalGrowth = growthOverride != null ? growthOverride : v.terminalGrowth();

        if (wacc <= terminalGrowth) {
            throw new IllegalArgumentException("WACC must be greater than terminal growth.");
        }

        List<ValuationResponse.ForecastYear> forecast = new ArrayList<>();
        double previousRevenue = h.revenueCrore();
        double pvForecast = 0.0;
        for (int i = 0; i < f.revenueGrowth().size(); i++) {
            double growth = f.revenueGrowth().get(i);
            double revenue = previousRevenue * (1.0 + growth);
            double margin = f.ebitMargins().get(i);
            double ebit = revenue * margin;
            double tax = ebit * v.taxRate();
            double da = revenue * f.daPercentRevenue();
            double capex = revenue * f.capexPercentRevenue();
            double nwc = revenue * f.changeNwcPercentRevenue();
            double ufcf = ebit - tax + da - capex - nwc;
            double discountFactor = 1.0 / Math.pow(1.0 + wacc, i + 1);
            double pv = ufcf * discountFactor;
            pvForecast += pv;
            forecast.add(new ValuationResponse.ForecastYear(
                "Year " + (i + 1), revenue, growth, margin, ebit, tax, da, capex, nwc,
                ufcf, discountFactor, pv
            ));
            previousRevenue = revenue;
        }

        double finalUfcf = forecast.get(forecast.size() - 1).ufcfCrore();
        double terminalValue = finalUfcf * (1.0 + terminalGrowth) / (wacc - terminalGrowth);
        double pvTerminal = terminalValue / Math.pow(1.0 + wacc, forecast.size());
        double enterpriseValue = pvForecast + pvTerminal;
        double equityValue = enterpriseValue - v.debtCrore() + v.cashCrore();
        double perShare = equityValue / v.dilutedSharesCrore();
        double upside = perShare / v.currentSharePriceInr() - 1.0;

        Map<String, Double> metrics = new LinkedHashMap<>();
        metrics.put("Cost of Equity", costOfEquity);
        metrics.put("WACC", wacc);
        metrics.put("Terminal Growth", terminalGrowth);
        metrics.put("PV of Forecast UFCF (INR crore)", pvForecast);
        metrics.put("Terminal Value (INR crore)", terminalValue);
        metrics.put("PV of Terminal Value (INR crore)", pvTerminal);
        metrics.put("Enterprise Value (INR crore)", enterpriseValue);
        metrics.put("Cash (INR crore)", v.cashCrore());
        metrics.put("Debt (INR crore)", v.debtCrore());
        metrics.put("Equity Value (INR crore)", equityValue);
        metrics.put("Diluted Shares (crore)", v.dilutedSharesCrore());
        metrics.put("Implied Value per Share (INR)", perShare);
        metrics.put("Current Share Price (INR; demo input)", v.currentSharePriceInr());
        metrics.put("Implied Upside / (Downside)", upside);

        return new ValuationResponse(request.companyName(), request.ticker(), "INR",
                "ILLUSTRATIVE DEMO INPUTS — replace with verified financial data before publishing",
                forecast, metrics);
    }
}
