package com.portfolio.dcf;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DcfValuationApplication {
    public static void main(String[] args) {
        SpringApplication.run(DcfValuationApplication.class, args);
    }
}
