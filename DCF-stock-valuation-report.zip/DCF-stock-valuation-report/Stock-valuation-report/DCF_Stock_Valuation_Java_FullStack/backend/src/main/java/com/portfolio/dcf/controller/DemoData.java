package com.portfolio.dcf.controller;

import com.portfolio.dcf.model.ValuationRequest;
import java.util.List;

public final class DemoData {
    private DemoData() {}
    public static ValuationRequest request() {
        return new ValuationRequest(
            "Tata Consultancy Services (TCS)", "TCS.NS",
            new ValuationRequest.HistoricalInputs(240000, 0.245, 0.035, 0.025, 0.005),
            new ValuationRequest.ForecastInputs(
                List.of(0.08, 0.08, 0.075, 0.07, 0.065),
                List.of(0.245, 0.245, 0.246, 0.247, 0.248),
                0.035, 0.025, 0.005
            ),
            new ValuationRequest.ValuationInputs(
                0.25, 0.07, 0.055, 0.9, 0.075, 0.95, 0.05,
                30000, 10000, 362, 4000, 0.045
            )
        );
    }
}
