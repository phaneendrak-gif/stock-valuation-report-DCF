package com.portfolio.dcf.model;

import java.util.List;
import java.util.Map;

public record ValuationResponse(
    String companyName,
    String ticker,
    String currency,
    String dataStatus,
    List<ForecastYear> forecast,
    Map<String, Double> metrics
) {
    public record ForecastYear(
        String year, double revenueCrore, double revenueGrowth, double ebitMargin,
        double ebitCrore, double taxOnEbitCrore, double daCrore, double capexCrore,
        double changeNwcCrore, double ufcfCrore, double discountFactor, double pvUfcfCrore
    ) {}
}
