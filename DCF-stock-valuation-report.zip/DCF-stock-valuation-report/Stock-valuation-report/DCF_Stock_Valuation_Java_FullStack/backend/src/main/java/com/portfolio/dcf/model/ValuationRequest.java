package com.portfolio.dcf.model;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.util.List;

public record ValuationRequest(
    @NotBlank String companyName,
    @NotBlank String ticker,
    @NotNull @Valid HistoricalInputs historical,
    @NotNull @Valid ForecastInputs forecast,
    @NotNull @Valid ValuationInputs valuation
) {
    public record HistoricalInputs(
        @Positive double revenueCrore,
        @DecimalMin("0.0") @DecimalMax("1.0") double ebitMargin,
        @DecimalMin("0.0") @DecimalMax("1.0") double daPercentRevenue,
        @DecimalMin("0.0") @DecimalMax("1.0") double capexPercentRevenue,
        @DecimalMin("0.0") @DecimalMax("1.0") double changeNwcPercentRevenue
    ) {}

    public record ForecastInputs(
        @NotEmpty List<@DecimalMin("-0.5") @DecimalMax("1.0") Double> revenueGrowth,
        @NotEmpty List<@DecimalMin("0.0") @DecimalMax("1.0") Double> ebitMargins,
        @DecimalMin("0.0") @DecimalMax("1.0") double daPercentRevenue,
        @DecimalMin("0.0") @DecimalMax("1.0") double capexPercentRevenue,
        @DecimalMin("0.0") @DecimalMax("1.0") double changeNwcPercentRevenue
    ) {}

    public record ValuationInputs(
        @DecimalMin("0.0") @DecimalMax("0.5") double taxRate,
        @DecimalMin("0.0") @DecimalMax("0.3") double riskFreeRate,
        @DecimalMin("0.0") @DecimalMax("0.3") double equityRiskPremium,
        @DecimalMin("0.0") @DecimalMax("3.0") double beta,
        @DecimalMin("0.0") @DecimalMax("0.5") double preTaxCostOfDebt,
        @DecimalMin("0.0") @DecimalMax("1.0") double equityWeight,
        @DecimalMin("0.0") @DecimalMax("1.0") double debtWeight,
        @PositiveOrZero double cashCrore,
        @PositiveOrZero double debtCrore,
        @Positive double dilutedSharesCrore,
        @Positive double currentSharePriceInr,
        @DecimalMin("0.0") @DecimalMax("0.15") double terminalGrowth
    ) {}
}
