package com.portfolio.dcf.service;

import com.portfolio.dcf.controller.DemoData;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class DcfValuationServiceTest {
    private final DcfValuationService service = new DcfValuationService();

    @Test
    void calculatesPositiveValuationForDemoInputs() {
        var result = service.calculate(DemoData.request(), null, null);
        assertEquals(5, result.forecast().size());
        assertTrue(result.metrics().get("WACC") > result.metrics().get("Terminal Growth"));
        assertTrue(result.metrics().get("Implied Value per Share (INR)") > 0);
    }

    @Test
    void rejectsWaccBelowTerminalGrowth() {
        assertThrows(IllegalArgumentException.class,
            () -> service.calculate(DemoData.request(), 0.03, 0.04));
    }
}
